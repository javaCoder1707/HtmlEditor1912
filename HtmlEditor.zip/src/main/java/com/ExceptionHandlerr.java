package com;

public class ExceptionHandlerr extends Exception {
    public static void log(Exception e){
        System.out.println(e.toString());
    }
}
